var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");

function rand(max) {
  return Math.floor(Math.random() * max);
}

class V2{
	constructor(x, y){
		this.x = x;
		this.y = y;
	}
}

class Color{
	constructor(r, g, b){
		this.r = r;
		this.g = g;
		this.b = b;
	}
}

class Ball{
	constructor(v, c, w){
		this.v = v;
		this.c = c;
		this.width = w;
		this.a = new V2((rand(100) - 50) / 100, (rand(100) - 50) / 100);
	}
}

var c_want = new Color(20, 20, 20);
var c_is = new Color(20, 20, 20);
var aaa = 6;
var aaav = 6;

var ball = [];

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

for(var i = 0; i < 100; i++){
	ball[ball.length] = new Ball(new V2(rand(canvas.width), rand(canvas.height)), new Color(rand(255), rand(255), rand(255)), rand(50));
}

var scroll = window.pageYOffset;

function loop(){
	scroll = window.pageYOffset;
	canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
	ctx.fillStyle = "rgb(20, 20, 20)";
ctx.fillRect(0, 0, canvas.width, canvas.height);

for(var i = 0; i < ball.length; i++){
	ball[i].v.x += ball[i].a.x;
	ball[i].v.y += ball[i].a.y;
	if(ball[i].v.x < 0){
		ball[i].a.x = -1 * ball[i].a.x;
	}
	if(ball[i].v.y < 0){
		ball[i].a.y = -1 * ball[i].a.y;
	}

	if(ball[i].v.y > canvas.height){
		ball[i].a.y = -1 * ball[i].a.y;
	}

	if(ball[i].v.x > canvas.width){
		ball[i].a.x = -1 * ball[i].a.x;
	}
}

for(var i = 0; i < ball.length; i++){
	ctx.fillStyle = "rgb(" + ball[i].c.r + ", " + ball[i].c.g + ", " + ball[i].c.b + ")";
	ctx.beginPath();
	ctx.arc(ball[i].v.x, ball[i].v.y, ball[i].width, 0, 2 * Math.PI);
	ctx.fill();
}

	if(scroll < canvas.height / 2){
		c_want = new Color(20, 20, 20);
		aaav = 6;
	}else{
		c_want = new Color(220, 220, 220);
		aaav = 9;
	}
console.log(aaa);
	$(".dark").css("background-color", "rgba(" + c_is.r + ", " + c_is.g + ", " + c_is.b + ", " + aaa / 10 + ")");
	if(c_is.r > c_want.r){
		c_is.r -= 3;
	}else if(c_is.r < c_want.r){
		c_is.r += 3;
	}
	if(c_is.g > c_want.g){
		c_is.g -= 3;
	}else if(c_is.g < c_want.g){
		c_is.g += 3;
	}
	if(c_is.b > c_want.b){
		c_is.b -= 3;
	}else if(c_is.b < c_want.b){
		c_is.b += 3;
	}
	if(aaa > aaav){
		aaa--;
	}else if(aaa < aaav){
		aaa++;
	}

	setTimeout(loop, 2);
}
loop();

